public class TestUser {
    public static void main(String[] args) {
        User u = new User("U01", "Nguyen Van A");
        u.displayUser();
    }
}

public class TestBook {
    public static void main(String[] args) {
        Book b = new Book("B01", "Thinking in Java", "Bruce Eckel");
        b.displayInfo();
    }
}

public class TestUserBook {
    public static void main(String[] args) {
        UserBook ub = new UserBook("B01", "U01", "2025-05-09");
        ub.displayBorrowInfo();
    }
}

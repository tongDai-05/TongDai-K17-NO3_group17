# Xây dựng ứng dụng quản lý thư viện

Chi tiết xem trong phần mô tả ở lớp học.
